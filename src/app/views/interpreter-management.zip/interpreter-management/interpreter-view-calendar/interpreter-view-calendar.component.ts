import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interpreter-view-calendar',
  templateUrl: './interpreter-view-calendar.component.html',
  styleUrls: ['./interpreter-view-calendar.component.scss']
})
export class InterpreterViewCalendarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
